
local ADDON, UPA = ...

UPA.price.providers = UPA.price.providers or {}

UPA.price.providers["Fallback"] = {
    Name = "Fallback",
    GetMatPriceById = function(_) return nil end,
    GetMatPrice     = function(_) return nil end,
    GetRecipePrice  = function(_) return nil end,
}
