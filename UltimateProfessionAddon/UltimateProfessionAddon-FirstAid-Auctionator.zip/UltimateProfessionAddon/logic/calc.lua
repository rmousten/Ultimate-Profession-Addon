
local ADDON, UPA = ...

local P = { orange=1.0, yellow=0.5, green=0.2, gray=0.0 }
UPA.calc.ExpectedSkillup = P

local function colorAt(skill, r)
    if skill < r.yellow then return "orange"
    elseif skill < r.green then return "yellow"
    elseif skill < r.gray then return "green"
    else return "gray" end
end

local function levelsUntilNextColor(skill, r)
    local c = colorAt(skill, r)
    if c == "orange" then return math.max(0, r.yellow - skill)
    if c == "yellow" then return math.max(0, r.green - skill)
    if c == "green"  then return math.max(0, r.gray - skill)
    return 0
end

local function matCostCopper(recipe, provider)
    local total = 0
    for name, qty in pairs(recipe.materials or {}) do
        local id = recipe.materialIds and recipe.materialIds[name] or nil
        local unit = nil
        if id and provider.GetMatPriceById then
            unit = provider.GetMatPriceById(id)
        end
        unit = unit or (provider.GetMatPrice and provider.GetMatPrice(name)) or 0
        total = total + (unit or 0) * qty
    end
    return total
end

local function learnCostCopper(recipe)
    if recipe.source == "Train" then
        return UPA.util.MoneyStringToCopper(recipe.trainingCost)
    end
    return 0
end

local function vendorValueCopper(recipe)
    return UPA.util.MoneyStringToCopper(recipe.vendorValue or "00g 00s 00c")
end

function UPA.calc:ScoreRecipe(recipe, currentSkill, provider)
    local range = recipe.skillRange; if not range then return end
    local clr = colorAt(currentSkill, range)
    local expected = P[clr] or 0
    local skillAvail = levelsUntilNextColor(currentSkill, range); if skillAvail <= 0 then skillAvail = 1 end
    local mats = matCostCopper(recipe, provider)
    local learn = learnCostCopper(recipe)
    local vendor = vendorValueCopper(recipe)
    local score = (mats * expected) + (learn / skillAvail) - vendor
    return {
        name = recipe.name, color = clr, expectedSkillup = expected, skillAvail = skillAvail,
        matCost = mats, learnCost = learn, vendorVal = vendor, score = score, recipe = recipe
    }
end

function UPA.calc:BuildPath(profName, currentSkill, targetSkill)
    local prof = UPA.professions[profName]; if not prof then return nil, "Unknown profession" end
    targetSkill = targetSkill or 300
    local provider = UPA:GetPriceProvider()
    local path, totals = {}, { mat=0, learn=0, vendor=0, score=0 }
    local learnedOnce = {}

    local safety = 0
    while currentSkill < targetSkill and safety < 500:
        safety = safety + 1
        local bestRow, bestRecipe
        for _, r in ipairs(prof.recipes) do
            local clr = colorAt(currentSkill, r.skillRange)
            local exp = P[clr] or 0
            if exp > 0 then
                local row = self:ScoreRecipe(r, currentSkill, provider)
                row.learnCost = 0 -- we'll charge learn once when committing
                if not bestRow or row.score < bestRow.score then
                    bestRow, bestRecipe = row, r
                end
            end
        end
        if not bestRecipe then break end

        local r = bestRecipe
        local clr = colorAt(currentSkill, r.skillRange)
        local exp = P[clr]
        local nextDelta = levelsUntilNextColor(currentSkill, r.skillRange)
        local goalDelta = math.min((nextDelta > 0) and nextDelta or (targetSkill - currentSkill), (targetSkill - currentSkill))
        if goalDelta <= 0 then goalDelta = targetSkill - currentSkill end
        local crafts = math.max(1, math.ceil(goalDelta / exp))

        local matsUnit = matCostCopper(r, provider)
        local vendorUnit = vendorValueCopper(r)
        local learn = 0
        if not learnedOnce[r.name] then learnedOnce[r.name] = true; learn = learnCostCopper(r) end

        local matCostTotal = matsUnit * crafts
        local vendorTotal  = vendorUnit * crafts
        local expectedSkillGain = exp * crafts
        local nextSkill = math.min(targetSkill, currentSkill + expectedSkillGain)

        table.insert(path, {
            name = r.name,
            color = clr,
            crafts = crafts,
            expectedGain = expectedSkillGain,
            from = currentSkill,
            to = nextSkill,
            matCost = matCostTotal,
            learnCost = learn,
            vendorValue = vendorTotal,
            breakdown = { matUnit=matsUnit, vendorUnit=vendorUnit, expPerCraft=exp }
        })

        totals.mat   = totals.mat   + matCostTotal
        totals.learn = totals.learn + learn
        totals.vendor= totals.vendor+ vendorTotal
        totals.score = totals.score + (matCostTotal - vendorTotal + learn)

        currentSkill = nextSkill
    end

    return { steps = path, totals = totals, finalSkill = currentSkill, target = targetSkill }
end
