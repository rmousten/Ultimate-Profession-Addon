
UltimateProfessionAddon (First Aid + Auctionator)
=================================================

What this is
------------
An MVP addon that adds a **Calculate** button to the **First Aid** profession window. It builds a greedy, price-aware path from your current First Aid skill to a target (default 300) using **Auctionator** prices.

Install
-------
1) Close the game.
2) Unzip so the folder structure is: `Interface/AddOns/UltimateProfessionAddon/`
3) Ensure Auctionator is installed and enabled.
4) Launch the game and `/reload` if needed.

Use
---
- Open **First Aid** → click **Calculate** (bottom-right of the profession window).
- In the popup, set your current/target skill and click **Calculate** again.

Notes
-----
- Prices come from Auctionator's last known data. Open the Auction House to refresh.
- Missing prices are treated as 0.
- Training costs are charged once per recipe when first used in the path.
- You can change the price source later in SavedVariables if needed (defaults to Auctionator only).

Files
-----
- `UltimateProfessionAddon.toc` – load order and metadata
- `core/` – namespace, events, saved variables
- `database/firstaid.lua` – First Aid recipes (with item IDs)
- `logic/calc.lua` – scoring and path building
- `scan/auctionator.lua` – Auctionator provider (ID preferred, name fallback)
- `ui/frame.lua` – Calculate button + results window

Troubleshooting
---------------
- If the button doesn't appear, ensure the TradeSkill window is First Aid and the addon is loaded.
- If prices show 0, open the Auction House to let Auctionator populate data.
- If the addon doesn't load, bump the Interface number in the `.toc` file to match your client.
